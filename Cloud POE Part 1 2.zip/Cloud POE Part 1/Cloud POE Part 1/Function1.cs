using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;

namespace Cloud_POE_Part_1
{

    public static class Function1
    {
        private static readonly HttpClient HttpClient = new HttpClient();

        [FunctionName("ST10031913")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string id = req.Query["id"];

            if (!string.IsNullOrEmpty(id) && VaccinationData.TryGetValue(id, out var record))
            {
                return new OkObjectResult($"Vaccination Status for ID {id}:\n" +
                    $"Name: {record.Name}\n" +
                    $"Surname: {record.Surname}\n" +
                    $"Birthday: {record.Birthday}\n" +
                    $"Vaccination Status: {record.VaccinationStatus}\n" +
                    $"Vaccination Date: {record.VaccinationDate}");
            }
            else
            {


                string responseMessage = "Enter id to view patience vaccination data"; 
          
                    

                return new OkObjectResult(responseMessage);
            }
        }

        private static readonly Dictionary<string, VaccinationRecord> VaccinationData = new Dictionary<string, VaccinationRecord>
        {
            ["8001155488087"] = new VaccinationRecord
            {
                Name = "Harry",
                Surname = "Dilinger",
                Birthday = "1980-01-15",
                VaccinationStatus = "Vaccinated",
                VaccinationDate = "2022-07-01"
            },
            ["9505205488087"] = new VaccinationRecord
            {
                Name = "Nkosazana",
                Surname = "Ndlovu",
                Birthday = "1995-05-20",
                VaccinationStatus = "Vaccinated",
                VaccinationDate = "2022-06-15"
            },
            ["0411305488087"] = new VaccinationRecord
            {
                Name = "Nkosazana",
                Surname = "Ndlovu",
                Birthday = "2004-11-30",
                VaccinationStatus = "Vaccinated",
                VaccinationDate = "2022-06-15"
            },
            ["0004235488087"] = new VaccinationRecord
            {
                Name = "Graham",
                Surname = "Potter",
                Birthday = "2000-04-23",
                VaccinationStatus = "Not Vaccinated",
                VaccinationDate = "-"
            }
        };
    }

    public class VaccinationRecord
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Birthday { get; set; }
        public string VaccinationStatus { get; set; }
        public string VaccinationDate { get; set; }
    }
}
